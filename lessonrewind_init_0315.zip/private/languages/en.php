<?php
return 
array(
'asdsadsa sadas' => 'asdsadsa sadas'
);