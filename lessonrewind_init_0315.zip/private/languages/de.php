<?php
return 
array(
'sim1ple asdasd' => 'einfa21321321ch'
,'simpl12e' => 'einfach'
,'simp2le' => 'einfach'
);