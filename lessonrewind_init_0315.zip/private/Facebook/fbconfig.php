<?php
/*define('APP_ID', '157378124453340');
define('APP_SECRET', '4e5ce2be48da482e44060481772b6bf6');*/

define('APP_ID', '263527243841319');
define('APP_SECRET', '4a49f2fa17a7dd353dce71c8ab434312');
?>