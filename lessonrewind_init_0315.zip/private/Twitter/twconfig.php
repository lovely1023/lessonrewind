<?php
// -- TheJamStop  --//
define('YOUR_CONSUMER_KEY','d5Ryqng5AuX7QipADsGNg');
define('YOUR_CONSUMER_SECRET','x1e4Q8M8tJJDWPIj7zdc6o4Zsp1Xmw6nNDSehrAdw');

// -- TheJamStop  --//



?>
