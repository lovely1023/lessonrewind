<?php
$consumer_key = '78EnS8I8rYH4wbbnWg';
$consumer_secret = 'EZs5pFy8H0KNApCtHMm1BiQrA6UfLfIhuaDkYfE45m0';
?>
